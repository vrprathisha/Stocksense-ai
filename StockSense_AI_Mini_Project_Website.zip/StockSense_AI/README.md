# StockSense AI — Mini Project

A Flask + Python + scikit-learn stock market volatility dashboard.

## Run
1. Install Python 3.10+.
2. Extract this ZIP and open a terminal in this folder.
3. Run `pip install -r requirements.txt`
4. Run `python app.py`
5. Open `http://127.0.0.1:5000`

## Tickers
India: `RELIANCE.NS`, `TCS.NS`, `INFY.NS`, `^NSEI`, `^NSEBANK`
US: `AAPL`, `MSFT`, `NVDA`, `GOOGL`, `TSLA`

## Features
- Market watchlist and periodic refresh
- Historical price chart with best-effort 5-minute quote
- RSI, moving averages and annualised realised volatility
- Random Forest Regression trained on historical returns, lagged returns,
  moving-average gaps, rolling volatility and momentum
- Five-session illustrative model forecast and chronological holdout MAE

## Important
Data is fetched from Yahoo Finance via yfinance. It is not guaranteed tick-by-tick
real-time data; intraday data may be delayed, rate-limited or unavailable. The
app falls back to the latest daily close and labels the quote accordingly.
The forecast is an educational ML demonstration, not financial advice or a
reliable trading signal. For a public deployment, use a licensed market-data
provider/API, add caching and rate limits, disable Flask debug mode, and deploy
behind HTTPS.
