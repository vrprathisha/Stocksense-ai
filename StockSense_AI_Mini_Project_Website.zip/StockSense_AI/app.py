from flask import Flask, render_template, jsonify
import yfinance as yf, pandas as pd, numpy as np, re
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from datetime import datetime, timezone
app=Flask(__name__)
NAMES={"RELIANCE.NS":"Reliance Industries","TCS.NS":"Tata Consultancy Services","INFY.NS":"Infosys","^NSEI":"NIFTY 50","^NSEBANK":"NIFTY BANK","AAPL":"Apple","MSFT":"Microsoft","NVDA":"NVIDIA","GOOGL":"Alphabet","TSLA":"Tesla"}
WATCH=["RELIANCE.NS","TCS.NS","INFY.NS","^NSEI","^NSEBANK"]
def history(s,p="2y",i="1d"):
 d=yf.download(s,period=p,interval=i,auto_adjust=True,progress=False,threads=False)
 if d is None or d.empty: raise ValueError("No data found. Check the ticker symbol and try again.")
 if isinstance(d.columns,pd.MultiIndex): d.columns=d.columns.get_level_values(0)
 d.columns=[str(c).title() for c in d.columns]
 return d.dropna()
def features(c):
 x=pd.DataFrame({"Close":c}); r=x.Close.pct_change()
 x["Lag1"]=r.shift(1);x["Lag2"]=r.shift(2);x["Lag3"]=r.shift(3)
 x["MA5"]=x.Close/x.Close.rolling(5).mean()-1;x["MA20"]=x.Close/x.Close.rolling(20).mean()-1
 x["Vol10"]=r.rolling(10).std();x["Mom5"]=x.Close.pct_change(5)
 return x.replace([np.inf,-np.inf],np.nan).dropna()
def forecast(d):
 c=d.Close.astype(float); f=features(c); cols=["Lag1","Lag2","Lag3","MA5","MA20","Vol10","Mom5"]
 if len(f)<80: raise ValueError("Not enough historical data to train the model.")
 X=f[cols];y=f.Close.pct_change().reindex(f.index).clip(-.15,.15)
 # Features are aligned to the next return: train using today's features to predict tomorrow's return.
 y=c.pct_change().shift(-1).reindex(X.index).dropna();X=X.loc[y.index]
 split=max(50,int(len(X)*.8));m=RandomForestRegressor(n_estimators=220,max_depth=7,min_samples_leaf=3,random_state=42,n_jobs=-1)
 m.fit(X.iloc[:split],y.iloc[:split]); mae=mean_absolute_error(y.iloc[split:],m.predict(X.iloc[split:])) if len(X)>split else None
 m.fit(X,y); roll=list(c.values[-30:]); out=[]
 for k in range(1,6):
  s=pd.Series(roll);r=s.pct_change()
  row={"Lag1":r.iloc[-1],"Lag2":r.iloc[-2],"Lag3":r.iloc[-3],"MA5":s.iloc[-1]/s.tail(5).mean()-1,"MA20":s.iloc[-1]/s.tail(20).mean()-1,"Vol10":r.tail(10).std(),"Mom5":s.iloc[-1]/s.iloc[-6]-1}
  ret=float(np.clip(m.predict(pd.DataFrame([row])[cols])[0],-.08,.08));price=roll[-1]*(1+ret);roll.append(price)
  out.append({"date":(pd.Timestamp(c.index[-1])+pd.offsets.BDay(k)).strftime("%Y-%m-%d"),"price":round(price,2),"return_pct":round(ret*100,3)})
 return out,mae,len(X)
def rsi(c):
 d=c.diff();g=d.clip(lower=0).rolling(14).mean();l=-d.clip(upper=0).rolling(14).mean()
 return float((100-100/(1+g/l.replace(0,np.nan))).dropna().iloc[-1])
@app.route("/")
def home(): return render_template("index.html")
@app.route("/api/market")
def market():
 items=[]
 for s in WATCH:
  try:
   c=history(s,"5d","1d").Close.astype(float);items.append({"symbol":s,"name":NAMES.get(s,s),"price":round(float(c.iloc[-1]),2),"change_pct":round(float((c.iloc[-1]/c.iloc[-2]-1)*100),2)})
  except Exception: items.append({"symbol":s,"name":NAMES.get(s,s),"price":None,"change_pct":None})
 return jsonify(items=items,updated_at=datetime.now(timezone.utc).isoformat())
@app.route("/api/stock/<path:symbol>")
def stock(symbol):
 try:
  s=symbol.upper().strip()
  if not re.fullmatch(r"[A-Z0-9^=._-]{1,20}",s): raise ValueError("Invalid ticker symbol.")
  d=history(s);c=d.Close.astype(float);pred,mae,n=forecast(d)
  try:
   intra=history(s,"5d","5m");q=intra.Close.dropna();chart=[{"time":i.strftime("%d %b %H:%M"),"price":round(float(v),2)} for i,v in q.items()];price=float(q.iloc[-1]);qt=intra.index[-1].strftime("%Y-%m-%d %H:%M");qtype="Latest available 5-minute quote"
  except Exception:
   chart=[{"time":i.strftime("%d %b %Y"),"price":round(float(v),2)} for i,v in c.tail(120).items()];price=float(c.iloc[-1]);qt=c.index[-1].strftime("%Y-%m-%d");qtype="Latest available daily close"
  prev=float(c.iloc[-2]);vol=float(c.pct_change().dropna().tail(20).std()*np.sqrt(252)*100)
  return jsonify(symbol=s,name=NAMES.get(s,s),price=round(price,2),change_pct=round((price/prev-1)*100,2),quote_time=qt,quote_type=qtype,currency="INR" if s.endswith(".NS") or s.startswith("^NSE") else "USD",chart=chart,forecast=pred,indicators={"rsi":round(rsi(c),2),"ma20":round(float(c.rolling(20).mean().iloc[-1]),2),"ma50":round(float(c.rolling(50).mean().iloc[-1]),2),"vol":round(vol,2)},model={"samples":n,"mae":round(float(mae),5) if mae is not None else None,"direction":"Bullish" if pred[-1]["price"]>price else "Bearish"},updated_at=datetime.now(timezone.utc).isoformat())
 except Exception as e:return jsonify(error=str(e)),400
if __name__=="__main__": app.run(debug=True,port=5000)
